# vim: set fileencoding=utf-8 :
#
# (C) 2006,2007 Guido Guenther <agx@sigxcpu.org>
"""Thinks common to all gbp commands"""

class GbpError(Exception):
    """Generic exception raised in git-buildpackage commands"""
    pass

# vim:et:ts=4:sw=4:
